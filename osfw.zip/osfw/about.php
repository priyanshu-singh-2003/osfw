<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Focus</title>
    <?php require("./includes/links.php"); ?>
    <link rel="stylesheet" href="./css/about.css">
 

</head>

<body class="bg-light">



    <!-- nav-bar -->  
    <?php include("./includes/header.php"); ?>
    <!-- nav-bar-end  -->

    <!-- hero section  -->
   <div class="container hero">
    <p class="text-center">

        Work Under Process
    </p>
   </div>

    <!-- hero section end -->



    <!--Footer-->
    <?php include("./includes/footer.php"); ?>
    <!--Footer end-->


    <!-- js -->

   

</body>

</html>