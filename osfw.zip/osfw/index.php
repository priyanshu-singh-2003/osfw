<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Focus</title>
    <?php require("./includes/links.php"); ?>
    <link rel="stylesheet" href="./css/index.css">



</head>

<body class="bg-light">



    <!-- nav-bar -->
    <?php include("./includes/header.php"); ?>
    <!-- nav-bar-end  -->

    <!-- hero section  -->
    <div class="container-fluid hero-sec p-0 m-0">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 order-lg-1 order-md-1 order-2">
                    <h1 class="text-light">Learn anything and <br> everything <br>
                        anytime with one step for <br> women</h1>
                    <p class="text-light">When women support women <br>
                        incredible things happen</p>
                        <div class="row align-items-center">
                            <div class="col-lg-2"><button type="button" class="hero-btn">Sign Up</button></div>
                            <div class="col-lg-6">
                            <input type="email" name="email" class="form-control shadow-none" placeholder="EMAIL" required>
                            </div>
                        </div>
                </div>
                <div class="col-lg-6 order-lg-2 order-md-1 order-1">
                    <img src="./images/hero.png" alt="">
                </div>
            </div>
        </div>
    </div>

    <!-- hero section end -->



    <!--Footer-->
    <?php include("./includes/footer.php"); ?>
    <!--Footer end-->


    <!-- js -->



</body>

</html>